import UIKit
//ViewController = gestisce LOGIN
class ViewController: UIViewController {
    
    @IBOutlet weak var textField_email: UITextField!
    @IBOutlet weak var textField_psw: UITextField!
    @IBOutlet weak var btn_login: UIButton!
    @IBOutlet weak var btn_goRegistrazione: UIButton!
    
    struct Token: Codable {
        let accessToken: String
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.textField_email.placeholder = "Inserisci email dell'account"
        self.textField_psw.placeholder = "Inserisci password dell'account"
        self.btn_login.layer.masksToBounds = true
        self.btn_login.layer.cornerRadius = 20
    }
    
    func hideKeyboard() {
        self.textField_email.resignFirstResponder()
        self.textField_psw.resignFirstResponder()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hideKeyboard()
    }
    
    
    //Funzione per creare alert per notificare la registrazione effettuata
    func createAlert(title: String, mex: String) -> Void{
        let alertView = UIAlertController(title: title, message: mex, preferredStyle: .actionSheet)
        let save = UIAlertAction(title: "OK", style: .default)
        alertView.addAction(save)
        present(alertView, animated: true, completion: nil)
    }
    
    //Action per andare al controller della registrazione
    @IBAction func btn_goToRegistrazione(_ sender: UIButton) {
        print("😴", #function)
        self.performSegue(withIdentifier: "segueToRegistrazione", sender: nil)
    }
    
    //---------
    func checkTextField(){
        let titolo: String = "Login"
        if self.textField_email.text != "" && self.textField_psw.text != ""{
            if !self.textField_email.text!.controlEmail {
                self.textField_email.textColor = .red
                createAlert(title: titolo, mex: "Email non valida")
            } else if !self.textField_psw.text!.controlPSW {
                self.textField_psw.textColor = .red
                createAlert(title: titolo, mex: "Password non valida. La password deve essere lunga almeno 6 caratteri, contenere una lettera maiuscola, minuscola, un numero ed un carattere speciale")
            } else {
                hideKeyboard()
                //aView = showSpinner()
                self.doLogin()
                print("Qua deve essere lanciato il mio metodo")
            }
            
        } else if self.textField_email.text == "" {
            self.textField_email.placeholder = "Inserisci una mail valida"
        } else if self.textField_psw.text == ""{
            self.textField_psw.placeholder = "Inserisci password valida"
        }
    }
    //---------
    func doLogin() -> Void{
        let url = URL(string: "https://lam21.iot-prism-lab.cs.unibo.it/auth/login")
        guard let requestUrl = url else { fatalError() }
        
        var request = URLRequest(url: requestUrl)
        request.httpMethod = "POST"
        guard let emailUtente = self.textField_email.text else {return}
        guard let passwordUtente = self.textField_psw.text else {return}
        
        let postString = "email=\(emailUtente)&password=\(passwordUtente)";
        
        request.httpBody = postString.data(using: String.Encoding.utf8);
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            if let error = error {
                print("Error took place \(error)")
                return
            }
            //let email10: String = "acquaAzzura1.verde@gmail.com"
            //let psw10: String = "acquaAzzura120_"
            
            //########
            if let data = data, let rispostaAPI = String(data: data, encoding: .utf8) {
                print(rispostaAPI)
                if(rispostaAPI.contains("accessToken")){
                    DispatchQueue.main.async {
                        print("🦋")
                        let alertView = UIAlertController(title: "LOGIN", message: "Login avvenuto con successo ti portiamo alla homepage dell'applicazione", preferredStyle: .actionSheet)
                        let save = UIAlertAction(title: "OK", style: .default, handler: { _ in
                            self.performSegue(withIdentifier: "segueToHomePage", sender: nil)
                            
                        })
                        alertView.addAction(save)
                        
                        self.present(alertView, animated: true, completion: nil)
                    }
                } else {
                    //Torna 401 e non 500
                    DispatchQueue.main.async {
                        self.createAlert(title: "LOGIN", mex: "Login fallito")
                    }
                }
                
                //########
                do{
                    let decoder = JSONDecoder.init()
                    let gettone: Token = try decoder.decode(Token.self, from: data)
                    print(gettone.accessToken)
                } catch let e{
                    print(e)
                }
                //########
            }
        }
        task.resume()
    }
    //---------
    
    
    //action per il button do login
    @IBAction func login_action(_ sender: UIButton) {
        print("😝",#function)
        self.checkTextField()
    }
    

    @IBAction func email_changed(_ sender: UITextField) {
        self.textField_email.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    }
    
    @IBAction func psw_changed(_ sender: UITextField) {
       self.textField_psw.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    }
}

//ATTENZIONE = ce un bug che se in file diversi quando faccio extension uso stesso nome, esplode
//Usare sempre nomi diversi quando estendo una classe
extension String {
    var controlEmail: Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: self)
    }
    
    var controlPSW: Bool {
        let regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[?!#$%&*+-.;<=>@^_~])[a-zA-z0-9?!#$%&*+-.;<=>@^_~].{6,}$"
        //NSPredicate = sto fissando la regola
        let testString = NSPredicate(format:"SELF MATCHES %@", regex)
        return testString.evaluate(with: self)
    }
}


/*
 COSE DA FARE
 -Mettere icona image alla mia app -> app icon --> FATTO
 -Mettere progetto online --> FATTO
 -Iniziare a vedere come fare il collegamento di xCode con il DB
 -Creare classe servizi
 -Studiare modo per dire all'utente che cosa è sbagliato (email o psw) quando il LOGIN fallisce
 -Pulire e ordinare il codice
 -Creare primi campi della homePage con button e label
 */



