import UIKit
//RegistrazioneViewController = si occupa di gestire la REGISTRAZIONE
class RegistrazioneViewController: UIViewController {
    
    @IBOutlet weak var textField_username: UITextField!
    @IBOutlet weak var textField_email: UITextField!
    @IBOutlet weak var textField_psw: UITextField!
    @IBOutlet weak var textField_confirmPSW: UITextField!
    @IBOutlet weak var btn_registrazione: UIButton!
    @IBOutlet weak var btn_back: UIButton!
    var aView: UIView?
    
    
    
    //###########################################################################################
    struct strutturaRegistrazione: Codable{
        let id: String
        let username: String
    }
    //##########################################################################################
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.textField_username.placeholder = "Inseri l'username dell'account"
        self.textField_email.placeholder = "Inserisci l'email dell'account"
        self.textField_psw.placeholder = "Inserisci la password dell'account"
        self.textField_confirmPSW.placeholder = "Reinserisci la password per verifica"
        self.btn_registrazione.isHidden = false
        
        btn_registrazione.layer.masksToBounds = true
        btn_registrazione.layer.cornerRadius = 20
    }
    
    func hideKeyboard() {
        textField_username.resignFirstResponder()
        textField_email.resignFirstResponder()
        textField_psw.resignFirstResponder()
        textField_confirmPSW.resignFirstResponder()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        hideKeyboard()
    }
    
    //Function che di volta in volta controlla sempre i campi di ogni singolo TextField
    func controlloTF(){
        let titolo: String = "Registrazione"
        if self.textField_username.text != "" && self.textField_email.text != "" && self.textField_psw.text != "" &&
            self.textField_confirmPSW.text != "" {
            if !self.textField_username.text!.isValidUsername {
                self.textField_username.textColor = .red
                createAlert(title: titolo, mex: "Username non valida. La username deve essere lunga almeno 4 caratteri e può contenere lettere maiuscole minuscole ed il carattere speciale '_'")
            } else if !self.textField_email.text!.isValidEmail {
                self.textField_email.textColor = .red
                createAlert(title: titolo, mex: "Email non valida")
            } else if self.textField_psw.text != self.textField_confirmPSW.text {
                self.textField_confirmPSW.textColor = .red
                createAlert(title: titolo, mex: "Attenzione verifica password non valida")
            } else if !self.textField_psw.text!.isValidPassword  {
                self.textField_psw.textColor = .red
                createAlert(title: titolo, mex: "Password non valida. La password deve essere lunga almeno 6 caratteri, contenere una lettera maiuscola, minuscola, un numero ed un carattere speciale")
                
            } else {
                hideKeyboard()
                aView = showSpinner()
                test()
            }
            
        } else if self.textField_username.text == "" {
            self.textField_username.placeholder = "Inserisci username"
        } else if self.textField_psw.text == ""{
            self.textField_psw.placeholder = "Inserisci password"
        }else if self.textField_confirmPSW.text == ""{
            self.textField_confirmPSW.placeholder = "Verificare la password"
        }else if self.textField_email.text == ""{
            self.textField_email.placeholder = "Inserire una mail valida"
            
        }
    }
    
    //Func che lancia il servizio API della registrazione
    func test() -> Void{
        var y: Bool = false
        
        let url1 = URL(string: "https://lam21.iot-prism-lab.cs.unibo.it/users")
        guard let urlGiusto = url1 else { fatalError() }
        
        var richiesta = URLRequest(url: urlGiusto)
        richiesta.httpMethod = "POST"
        
        guard let user10: String = self.textField_username.text else {fatalError()}
        guard let email10: String = self.textField_email.text else {fatalError()}
        guard let psw10: String = self.textField_psw.text else {fatalError()}
        
        let strPOST = "username=\(user10)&email=\(email10)&password=\(psw10)";
        
        richiesta.httpBody = strPOST.data(using: String.Encoding.utf8);
        
        let task1 = URLSession.shared.dataTask(with: richiesta) { (data1, response, error) in
            //server risposta
            DispatchQueue.main.async{
                self.stopSpinner(aView: self.aView)
            }
            
            if let error = error {
                print("Error took place \(error)")
                return
            }
            
            // Converti i dati di risposta HTTP in una stringa
            if let data1 = data1, let responseMex = String(data: data1, encoding: .utf8) {
                print(responseMex)
                if(responseMex.contains("id")){
                    print("OK")
                    y = true
                    print("SI BOOL", y)
                    
                    //DispatchQueue.main.async = quando devo modificare l'interfaccia(ex: per modificare label)
                    DispatchQueue.main.async {
                        let alertView = UIAlertController(title: "Registrazione completata", message: "Chiudi la finestra", preferredStyle: .actionSheet)
                        //let cancel = UIAlertAction(title: "Cancel", style: .destructive)
                        let save = UIAlertAction(title: "OK", style: .default, handler: { _ in
                            //Fare collegamento alla home
                            self.dismiss(animated: true, completion: nil)
                            
                        })
                        //alertView.addAction(cancel)
                        alertView.addAction(save)
                        
                        self.present(alertView, animated: true, completion: nil)
                    }
                    
                }
                
                if(responseMex.contains("500")){
                    print("NO REGISTRAZIONE")
                    y = false
                    print("NO BOOL", y)
                    DispatchQueue.main.async {
                        let alertView = UIAlertController(title: "Registrazione fallita", message: "Chiudi la finestra", preferredStyle: .actionSheet)
                        //let cancel = UIAlertAction(title: "Cancel", style: .destructive)
                        let save = UIAlertAction(title: "OK", style: .default)
                        //alertView.addAction(cancel)
                        alertView.addAction(save)
                        
                        self.present(alertView, animated: true, completion: nil)
                    }
                }
                
                do{
                    
                    let decoder = JSONDecoder.init()
                    let profiloLogin: strutturaRegistrazione = try decoder.decode(strutturaRegistrazione.self, from: data1)
                    print("ID",profiloLogin.id)
                    print("USERNAME",profiloLogin.username)
                    
                } catch let e{
                    print(e)
                }
            }
        }
        
        task1.resume()
        
    }
    /*
     func clearTextField() -> Void{
     self.textField_username.text = ""
     self.textField_email.text = ""
     self.textField_psw.text = ""
     self.textField_confirmPSW.text = ""
     }
     */
    
    //Funzione per creare alert per notificare la registrazione effettuata
    func createAlert(title: String, mex: String) -> Void{
        
        let alertView = UIAlertController(title: title, message: mex, preferredStyle: .actionSheet)
        //let cancel = UIAlertAction(title: "Cancel", style: .destructive)
        let save = UIAlertAction(title: "OK", style: .default)
        //alertView.addAction(cancel)
        alertView.addAction(save)
        
        present(alertView, animated: true, completion: nil)
        
    }
    
    //Action che lancia func per registrazione
    @IBAction func btn_registrazione_touchUp(_ sender: UIButton) {
        print("🤒", #function)
        controlloTF()
        //test()
    }
    
    @IBAction func back(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func username_changed(_ sender: UITextField) {
        self.textField_username.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    }
    
    @IBAction func email_changed(_ sender: UITextField) {
        self.textField_email.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    }
    
    @IBAction func psw_changed(_ sender: UITextField) {
        self.textField_psw.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    }
    
    @IBAction func pswConfirm_changed(_ sender: UITextField) {
        self.textField_confirmPSW.textColor = #colorLiteral(red: 0, green: 0, blue: 0, alpha: 1)
    }
}
//estendo metodi classe String
extension String {
    var isValidPassword: Bool {
        let regex = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[?!#$%&*+-.;<=>@^_~])[a-zA-z0-9?!#$%&*+-.;<=>@^_~].{6,}$"
        //NSPredicate = sto fissando la regola
        let testString = NSPredicate(format:"SELF MATCHES %@", regex)
        return testString.evaluate(with: self)
    }
    
    var isValidUsername: Bool {
        let regex = "^[a-zA-Z0-9_]{4,30}$"
        let testString = NSPredicate(format:"SELF MATCHES %@", regex)
        return testString.evaluate(with: self)
    }
    
    var isValidEmail: Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: self)
    }
}
/*
 var isValidCAN: Bool {
 let canRegEx = "[0-9]{6,6}$"
 let canPred = NSPredicate(format:"SELF MATCHES %@", canRegEx)
 return canPred.evaluate(with: self)
 }
 */

extension UIViewController {
    func showSpinner()-> UIView{
        let aView = UIView(frame: self.view.bounds)
        aView.backgroundColor = .gray
        aView.alpha = 0.7
        let ai = UIActivityIndicatorView(style: .whiteLarge)
        ai.center = aView.center
        ai.startAnimating()
        aView.addSubview(ai)
        self.view.addSubview(aView)
        return aView
    }
    
    func stopSpinner(aView: UIView?) {
        if aView != nil {
            aView!.removeFromSuperview()
        }
    }
}







/*
 COSE DA FARE
 -action per tornare al login
 -Controllare ogni volta i caratteri nella text field e far comparire i btn solo quando si scrive qualcosa
 -Fare IBOutlet delle textField?
 */

